const express = require('express');
const router = express.Router();
const employeeController = require('../controllers/employeeController');
const auth = require('../middleware/auth');

// Protected routes
router.post('/', auth, employeeController.createEmployee);
router.get('/', auth, employeeController.getAllEmployees);
router.get('/search', auth, employeeController.searchEmployees);
router.get('/:id', auth, employeeController.getEmployee);
router.put('/:id', auth, employeeController.updateEmployee);
router.delete('/:id', auth, employeeController.deleteEmployee);

module.exports = router;