import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
    Container,
    Paper,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    Button,
    TextField,
    Box,
    IconButton,
    Typography
} from '@mui/material';
import { Edit as EditIcon, Delete as DeleteIcon, Add as AddIcon } from '@mui/icons-material';
import { employeeService } from '../services/api';

const EmployeeList = () => {
    const [employees, setEmployees] = useState([]);
    const [searchQuery, setSearchQuery] = useState('');
    const navigate = useNavigate();

    useEffect(() => {
        loadEmployees();
    }, []);

    const loadEmployees = async() => {
        try {
            const response = await employeeService.getAll();
            setEmployees(response.data);
        } catch (error) {
            console.error('Error loading employees:', error);
        }
    };

    const handleSearch = async() => {
        try {
            const response = await employeeService.search(searchQuery);
            setEmployees(response.data);
        } catch (error) {
            console.error('Error searching employees:', error);
        }
    };

    const handleDelete = async(id) => {
        if (window.confirm('Are you sure you want to delete this employee?')) {
            try {
                await employeeService.delete(id);
                loadEmployees();
            } catch (error) {
                console.error('Error deleting employee:', error);
            }
        }
    };

    return ( <
        Container maxWidth = "lg" >
        <
        Box sx = {
            { mt: 4, mb: 4 }
        } >
        <
        Typography variant = "h4"
        component = "h1"
        gutterBottom >
        Employee List <
        /Typography> <
        Box sx = {
            { display: 'flex', mb: 2 }
        } >
        <
        TextField fullWidth label = "Search"
        value = { searchQuery }
        onChange = {
            (e) => setSearchQuery(e.target.value)
        }
        onKeyPress = {
            (e) => e.key === 'Enter' && handleSearch()
        }
        /> <
        Button variant = "contained"
        color = "primary"
        startIcon = { < AddIcon / > }
        onClick = {
            () => navigate('/employees/new')
        }
        sx = {
            { ml: 2 }
        } >
        Add Employee <
        /Button> < /
        Box > <
        TableContainer component = { Paper } >
        <
        Table >
        <
        TableHead >
        <
        TableRow >
        <
        TableCell > Name < /TableCell> <
        TableCell > Email < /TableCell> <
        TableCell > Department < /TableCell> <
        TableCell > Position < /TableCell> <
        TableCell > Type < /TableCell> <
        TableCell > Actions < /TableCell> < /
        TableRow > <
        /TableHead> <
        TableBody > {
            employees.map((employee) => ( <
                TableRow key = { employee._id } >
                <
                TableCell > { `${employee.firstName} ${employee.lastName}` } < /TableCell> <
                TableCell > { employee.email } < /TableCell> <
                TableCell > { employee.department } < /TableCell> <
                TableCell > { employee.position } < /TableCell> <
                TableCell > { employee.employeeType } < /TableCell> <
                TableCell >
                <
                IconButton color = "primary"
                onClick = {
                    () => navigate(`/employees/${employee._id}/edit`)
                } >
                <
                EditIcon / >
                <
                /IconButton> <
                IconButton color = "error"
                onClick = {
                    () => handleDelete(employee._id)
                } >
                <
                DeleteIcon / >
                <
                /IconButton> < /
                TableCell > <
                /TableRow>
            ))
        } <
        /TableBody> < /
        Table > <
        /TableContainer> < /
        Box > <
        /Container>
    );
};

export default EmployeeList;