import React from 'react';
import { useNavigate } from 'react-router-dom';
import { employeeService } from '../services/api';
import EmployeeForm from '../components/EmployeeForm';
import { Container, Paper, Typography, Box } from '@mui/material';

const AddEmployee = () => {
    const navigate = useNavigate();

    const handleAdd = async(values) => {
        try {
            await employeeService.create(values);
            navigate('/employees');
        } catch (error) {
            alert('Failed to add employee');
        }
    };

    return ( <
        Container maxWidth = "sm" >
        <
        Box sx = {
            { mt: 8 }
        } >
        <
        Paper elevation = { 3 }
        sx = {
            { p: 4 }
        } >
        <
        Typography variant = "h5"
        gutterBottom >
        Add Employee <
        /Typography> <
        EmployeeForm onSubmit = { handleAdd }
        /> < /
        Paper > <
        /Box> < /
        Container >
    );
};

export default AddEmployee;