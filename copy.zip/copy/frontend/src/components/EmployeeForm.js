import React from 'react';
import {
    TextField,
    Button,
    Grid,
    MenuItem,
    Box
} from '@mui/material';
import { useFormik } from 'formik';
import * as Yup from 'yup';

const employeeTypes = ['Full-time', 'Part-time', 'Contract', 'Intern'];

const validationSchema = Yup.object({
    firstName: Yup.string().required('First name is required'),
    lastName: Yup.string().required('Last name is required'),
    email: Yup.string().email('Invalid email address').required('Email is required'),
    phone: Yup.string().required('Phone number is required'),
    employeeType: Yup.string().required('Employee type is required'),
    department: Yup.string().required('Department is required'),
    position: Yup.string().required('Position is required')
});

const EmployeeForm = ({ initialValues, onSubmit, isEdit }) => {
    const formik = useFormik({
        initialValues: initialValues || {
            firstName: '',
            lastName: '',
            email: '',
            phone: '',
            employeeType: '',
            department: '',
            position: '',
            profilePic: ''
        },
        validationSchema,
        onSubmit: (values) => {
            onSubmit(values);
        }
    });

    return ( <
        form onSubmit = { formik.handleSubmit } >
        <
        Grid container spacing = { 3 } >
        <
        Grid item xs = { 12 }
        sm = { 6 } >
        <
        TextField fullWidth label = "First Name"
        name = "firstName"
        value = { formik.values.firstName }
        onChange = { formik.handleChange }
        error = { formik.touched.firstName && Boolean(formik.errors.firstName) }
        helperText = { formik.touched.firstName && formik.errors.firstName }
        /> < /
        Grid > <
        Grid item xs = { 12 }
        sm = { 6 } >
        <
        TextField fullWidth label = "Last Name"
        name = "lastName"
        value = { formik.values.lastName }
        onChange = { formik.handleChange }
        error = { formik.touched.lastName && Boolean(formik.errors.lastName) }
        helperText = { formik.touched.lastName && formik.errors.lastName }
        /> < /
        Grid > <
        Grid item xs = { 12 }
        sm = { 6 } >
        <
        TextField fullWidth label = "Email"
        name = "email"
        type = "email"
        value = { formik.values.email }
        onChange = { formik.handleChange }
        error = { formik.touched.email && Boolean(formik.errors.email) }
        helperText = { formik.touched.email && formik.errors.email }
        /> < /
        Grid > <
        Grid item xs = { 12 }
        sm = { 6 } >
        <
        TextField fullWidth label = "Phone"
        name = "phone"
        value = { formik.values.phone }
        onChange = { formik.handleChange }
        error = { formik.touched.phone && Boolean(formik.errors.phone) }
        helperText = { formik.touched.phone && formik.errors.phone }
        /> < /
        Grid > <
        Grid item xs = { 12 }
        sm = { 6 } >
        <
        TextField fullWidth select label = "Employee Type"
        name = "employeeType"
        value = { formik.values.employeeType }
        onChange = { formik.handleChange }
        error = { formik.touched.employeeType && Boolean(formik.errors.employeeType) }
        helperText = { formik.touched.employeeType && formik.errors.employeeType } > {
            employeeTypes.map((type) => ( <
                MenuItem key = { type }
                value = { type } > { type } <
                /MenuItem>
            ))
        } <
        /TextField> < /
        Grid > <
        Grid item xs = { 12 }
        sm = { 6 } >
        <
        TextField fullWidth label = "Department"
        name = "department"
        value = { formik.values.department }
        onChange = { formik.handleChange }
        error = { formik.touched.department && Boolean(formik.errors.department) }
        helperText = { formik.touched.department && formik.errors.department }
        /> < /
        Grid > <
        Grid item xs = { 12 } >
        <
        TextField fullWidth label = "Position"
        name = "position"
        value = { formik.values.position }
        onChange = { formik.handleChange }
        error = { formik.touched.position && Boolean(formik.errors.position) }
        helperText = { formik.touched.position && formik.errors.position }
        /> < /
        Grid > <
        Grid item xs = { 12 } >
        <
        Box sx = {
            { mt: 2 }
        } >
        <
        Button type = "submit"
        variant = "contained"
        color = "primary"
        size = "large" > { isEdit ? 'Update Employee' : 'Add Employee' } <
        /Button> < /
        Box > <
        /Grid> < /
        Grid > <
        /form>
    );
};

export default EmployeeForm;